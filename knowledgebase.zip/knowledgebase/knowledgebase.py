import streamlit as st
import pandas as pd
import os
import random

# ==========================================
# 1. 配置与初始化
# ==========================================
st.set_page_config(page_title="喝一杯 MVP", layout="mobile")  # 模拟手机端布局

# 定义本地图片文件夹路径
IMAGE_FOLDER = "images"
DATA_FILE = "drinks.csv"  # 确保Excel已另存为CSV格式


# ==========================================
# 2. PRD 6.1 核心算法逻辑：情绪 -> 风味映射
# ==========================================
def get_flavor_strategy(mood):
    """
    根据 PRD 6.1 章节实现的映射逻辑
    输入：用户情绪
    输出：推荐的风味关键词列表
    """
    mapping = {
        "😔 悲伤/失落": {
            "keywords": ["甜", "温热", "奶香", "治愈"],
            "desc": "基于'舒适食物'假说，为您推荐提升多巴胺的甜味与温热感饮品。"
        },
        "😡 愤怒/压力": {
            "keywords": ["气泡", "冰", "酸", "脆"],
            "desc": "通过气泡炸裂感和冰冷刺激来宣泄情绪。"
        },
        "😫 疲惫/困倦": {
            "keywords": ["酸", "柑橘", "咖啡因", "冷"],
            "desc": "利用酸味和低温刺激神经，帮助您快速回血。"
        },
        "🥳 快乐/庆祝": {
            "keywords": ["气泡", "果味", "酒精", "缤纷"],
            "desc": "气泡升腾象征情绪高涨，果味带来愉悦共鸣。"
        },
        "😐 无聊/平淡": {
            "keywords": ["复杂", "苦", "烟熏", "烈"],
            "desc": "复杂的风味结构能唤醒感官，缓解无聊。"
        }
    }
    return mapping.get(mood, {"keywords": [], "desc": "为您推荐经典口味。"})


# ==========================================
# 3. 数据处理与检索
# ==========================================
@st.cache_data  # 缓存数据，加快加载速度
def load_data():
    if not os.path.exists(DATA_FILE):
        return None
    return pd.read_csv(DATA_FILE)


def recommend_drink(df, mood_strategy, filters):
    """
    核心检索函数
    """
    # 1. 基础筛选：排除用户勾选的禁忌（如：不含酒精）
    filtered_df = df.copy()
    if filters.get("no_alcohol"):
        # 排除 category 包含 "酒精" 的
        filtered_df = filtered_df[~filtered_df['category'].str.contains("酒精", na=False)]

    if filters.get("no_caffeine"):
        # 排除 safety_flags 包含 "咖啡因" 的
        filtered_df = filtered_df[~filtered_df['safety_flags'].str.contains("咖啡因", na=False)]

    # 2. 核心算法：基于 PRD 6.1 的加权匹配
    # 只要饮品的 flavor_tags 或 mood_tags 包含策略中的关键词，就保留
    keywords = mood_strategy['keywords']
    if not keywords:
        return filtered_df.sample(3) if len(filtered_df) > 3 else filtered_df

    # 构建正则匹配模式 (例如: "甜|温热|奶香")
    pattern = "|".join(keywords)

    # 在“风味”和“情绪”两列中进行模糊匹配
    matches = filtered_df[
        filtered_df['flavor_tags'].str.contains(pattern, case=False, na=False) |
        filtered_df['mood_tags'].str.contains(pattern, case=False, na=False)
        ]

    return matches


# ==========================================
# 4. 前端界面渲染
# ==========================================
st.title("🍹 喝一杯 | 情绪饮品助手")

# --- Step 1: 获取用户输入 (模拟 PRD 用户旅程) ---
st.subheader("👋 现在的心情怎么样？")
selected_mood = st.selectbox(
    "请选择一个标签",
    ["😔 悲伤/失落", "😡 愤怒/压力", "😫 疲惫/困倦", "🥳 快乐/庆祝", "😐 无聊/平淡"]
)

# --- Step 2: 安全过滤 (PRD 安全合规要求) ---
with st.expander("⚙️ 偏好设置 (过敏/禁忌)"):
    no_alcohol = st.checkbox("🚫 不喝酒精 (开车/未成年)")
    no_caffeine = st.checkbox("🚫 不喝咖啡因 (睡不着)")

# --- Step 3: 执行推荐 ---
if st.button("✨ 生成我的专属推荐"):
    df = load_data()

    if df is None:
        st.error("❌ 找不到 Excel 数据文件 (drinks.csv)，请检查！")
    else:
        # 获取策略
        strategy = get_flavor_strategy(selected_mood)
        st.info(f"🧠 AI分析：{strategy['desc']}")

        # 执行检索
        filters = {"no_alcohol": no_alcohol, "no_caffeine": no_caffeine}
        results = recommend_drink(df, strategy, filters)

        if len(results) == 0:
            st.warning("抱歉，库存里暂时没有完全匹配的饮品，试试调整一下筛选条件？")
        else:
            # 随机取前3个展示，增加新鲜感
            show_count = min(3, len(results))
            final_picks = results.sample(show_count)

            st.success(f"为您精心挑选了 {len(results)} 款饮品，Top {show_count} 如下：")

            # --- 渲染卡片 ---
            for _, row in final_picks.iterrows():
                with st.container():
                    st.markdown("---")
                    # 1. 读取本地图片
                    img_path = os.path.join(IMAGE_FOLDER, str(row['image_filename']))

                    # 2. 图片展示 (核心视觉)
                    if os.path.exists(img_path):
                        st.image(img_path, use_container_width=True, caption=row['name_cn'])
                    else:
                        st.warning(f"⚠️ 图片缺失: {row['image_filename']}")

                    # 3. 文本信息
                    st.subheader(f"{row['name_cn']} ({row['name_en']})")
                    st.caption(f"🏷️ {row['category']} | ⭐ 难度: {row.get('difficulty', '1')}星")
                    st.write(f"**💡 推荐理由：** 这款饮品包含 `{row['flavor_tags']}` 元素，非常适合现在的你。")

                    # 4. 展开查看详情
                    with st.expander("查看制作配方"):
                        st.markdown(f"**原料：** {row['ingredients']}")
                        st.markdown(f"**步骤：** {row['steps_structured']}")